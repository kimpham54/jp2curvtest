def hello_world():
    print("Hello, world!")

def add_one(number):
    return number + 1