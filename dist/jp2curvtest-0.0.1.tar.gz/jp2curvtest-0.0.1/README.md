# jp2curvtest

This is a simple example module.

`python3 -m build`
`python3 -m twine upload --repository testpypi dist/*`
`python3 -m twine upload --repository pypi dist/*`

## Installation

```bash
pip install jp2curvtest
